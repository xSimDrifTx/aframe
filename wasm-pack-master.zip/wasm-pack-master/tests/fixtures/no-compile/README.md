# no-compile
> an example rust -> wasm project that won't compile!
