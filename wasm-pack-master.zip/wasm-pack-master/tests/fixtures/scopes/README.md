# scopes-hello-world
> an example rust -> wasm project
