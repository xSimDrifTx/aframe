# bad-cargo-toml
> an example rust -> wasm project
